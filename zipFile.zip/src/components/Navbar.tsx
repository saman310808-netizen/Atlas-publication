import React, { useState } from 'react';
import { Menu, X, Feather } from 'lucide-react';
import { AtlasLogo } from './AtlasLogo';

interface NavbarProps {
  onOpenContribute: () => void;
  activeSection?: string;
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenContribute,
  activeSection = 'home',
  onNavigate,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'stories', label: 'Stories' },
    { id: 'poetry', label: 'Poetry' },
    { id: 'travel', label: 'Travel' },
    { id: 'culture', label: 'Culture' },
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-[#F5E9DE]/95 backdrop-blur-md border-b border-[#3B241C]/15 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
          {/* Zone 1: Brand title, one line (Top Bar Contract) */}
          <button
            onClick={() => handleLinkClick('home')}
            className="group flex items-center gap-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#6D2638] rounded py-1 whitespace-nowrap shrink-0"
            aria-label="ATLAS Literary Journal Home"
          >
            <AtlasLogo variant="wordmark" />
            <span className="hidden lg:inline-block text-[11px] uppercase tracking-widest text-[#7A3E2D]/80 font-sans border-l border-[#3B241C]/20 pl-3">
              LSE International
            </span>
          </button>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-7 lg:gap-8 text-sm font-medium text-[#3B241C]">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`relative py-1 whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#6D2638] ${
                    isActive
                      ? 'text-[#6D2638] font-semibold'
                      : 'text-[#3B241C]/80 hover:text-[#3B241C]'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#6D2638]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenContribute}
              className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#F5E9DE] bg-[#6D2638] hover:bg-[#7A3E2D] active:bg-[#3B241C] transition-colors rounded shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#6D2638] whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <Feather className="w-3.5 h-3.5" />
              <span>Contribute</span>
            </button>

            {/* Mobile menu hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#3B241C] hover:text-[#6D2638] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#6D2638] rounded"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden bg-[#3B241C]/40 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-xs bg-[#F5E9DE] h-full shadow-2xl p-6 flex flex-col justify-between border-l border-[#3B241C]/20">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#3B241C]/15">
                <AtlasLogo variant="wordmark" />
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1.5 text-[#3B241C] hover:text-[#6D2638] rounded focus-visible:outline-none"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-4">
                <p className="text-[11px] uppercase tracking-wider text-[#7A3E2D] font-medium mb-3">
                  Publication Sections
                </p>
                <div className="flex flex-col gap-1">
                  {navLinks.map((link) => (
                    <button
                      key={link.id}
                      onClick={() => handleLinkClick(link.id)}
                      className={`text-left px-3 py-2.5 rounded text-base font-editorial transition-colors ${
                        activeSection === link.id
                          ? 'bg-[#D7C6AE]/40 text-[#6D2638] font-bold'
                          : 'text-[#3B241C] hover:bg-[#D7C6AE]/20'
                      }`}
                    >
                      {link.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-[#3B241C]/15 space-y-4">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenContribute();
                }}
                className="w-full py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#F5E9DE] bg-[#6D2638] hover:bg-[#7A3E2D] rounded shadow-xs flex items-center justify-center gap-2"
              >
                <Feather className="w-4 h-4" />
                <span>Submit to Atlas</span>
              </button>
              <p className="text-xs text-[#7A3E2D] text-center font-serif italic">
                London School of Economics & Political Science
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
