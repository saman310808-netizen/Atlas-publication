import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { IssueFeature } from './components/IssueFeature';
import { DiscoverySection } from './components/DiscoverySection';
import { CommunitySection } from './components/CommunitySection';
import { ContributeSection } from './components/ContributeSection';
import { Footer } from './components/Footer';
import { ArticleModal } from './components/ArticleModal';
import { SubmissionModal } from './components/SubmissionModal';
import { Article, Category } from './types';

export default function App() {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [isSubmissionModalOpen, setIsSubmissionModalOpen] = useState(false);
  const [submissionInitialCategory, setSubmissionInitialCategory] = useState<Category>('stories');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<Category | 'all'>('all');
  const [activeSection, setActiveSection] = useState('home');

  const handleOpenContribute = (category: Category = 'stories') => {
    setSubmissionInitialCategory(category);
    setIsSubmissionModalOpen(true);
  };

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);

    if (['stories', 'poetry', 'travel', 'culture'].includes(sectionId)) {
      setSelectedCategoryFilter(sectionId as Category);
      const element = document.getElementById('discover');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    if (sectionId === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleExploreIssue = () => {
    const el = document.getElementById('issue');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F5E9DE] text-[#3B241C] flex flex-col selection:bg-[#6D2638] selection:text-[#F5E9DE]">
      {/* Refined Navigation Bar */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenContribute={() => handleOpenContribute('stories')}
      />

      <main className="flex-1">
        {/* Striking Editorial Hero Section */}
        <HeroSection
          onSelectArticle={(art) => setSelectedArticle(art)}
          onExploreIssue={handleExploreIssue}
          onOpenContribute={() => handleOpenContribute('stories')}
        />

        {/* Featured Publication: Issue 04 */}
        <IssueFeature
          onSelectArticle={(art) => setSelectedArticle(art)}
        />

        {/* Discovery Section: Catalog for Short Stories, Poetry, Travel & Culture */}
        <DiscoverySection
          selectedCategoryFilter={selectedCategoryFilter}
          onSelectArticle={(art) => setSelectedArticle(art)}
        />

        {/* Student Community & Cross-Border Exchange */}
        <CommunitySection />

        {/* Call to Contribute for LSE Students */}
        <ContributeSection
          onOpenSubmissionModal={(category) => handleOpenContribute(category || 'stories')}
        />
      </main>

      {/* Literary Journal Footer with Colophon */}
      <Footer
        onOpenContribute={() => handleOpenContribute('stories')}
        onNavigate={handleNavigate}
      />

      {/* Reader View Modal */}
      <ArticleModal
        article={selectedArticle}
        onClose={() => setSelectedArticle(null)}
        onSelectArticle={(art) => setSelectedArticle(art)}
      />

      {/* Interactive Working Student Submission Modal */}
      <SubmissionModal
        isOpen={isSubmissionModalOpen}
        onClose={() => setIsSubmissionModalOpen(false)}
        initialCategory={submissionInitialCategory}
      />
    </div>
  );
}
